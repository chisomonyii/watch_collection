<?php

namespace App\Models;

use PDO;

abstract class Db
{
    public static function connect()
    {
        try {
            $host = $_ENV['DB_HOST'] ?? 'sql202.infinityfree.com';
            $port = $_ENV['DB_PORT'] ?? '3306';
            $db   = $_ENV['DB_NAME'] ?? 'if0_43336323_zeith';
            $user = $_ENV['DB_USER'] ?? 'if0_43336323';
            $password = $_ENV['DB_PASS'] ?? 'cand8Ded';

            $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";

            $connection = new PDO($dsn, $user, $password, [
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

            return $connection;

        } catch (\Exception $error) {
            echo "Database Connection Error: " . $error->getMessage();
            die();
        }
    }
}