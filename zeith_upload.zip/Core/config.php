<?php
define("CORE_PATH", __DIR__);
define("ROOT_DIR", dirname(__DIR__));
define("ROOT_URL", "/Zeith");

